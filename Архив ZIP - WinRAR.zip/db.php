<?php

require "libs/rb-mysql.php";
R::setup( 'mysql:host=site;dbname=site',
        'root', '' ); 
session_start()

?>